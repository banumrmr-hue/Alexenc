#!/bin/bash
# ══════════════════════════════
# ⚡ ALEX ENCODER ⚡ — VPS Setup
# ══════════════════════════════
# Compatible: Ubuntu 20.04 / 22.04 / Debian 11+
# Run as root: bash setup_vps.sh

set -e

echo ""
echo "⚡ ALEX ENCODER ⚡ — Starting Setup..."
echo "══════════════════════════════"

# ── 1. Update system ──────────────────────────────
echo "[1/7] Updating system packages..."
apt update -y && apt upgrade -y

# ── 2. Install dependencies ───────────────────────
echo "[2/7] Installing Python 3.11 & tools..."
apt install -y python3.11 python3.11-venv python3.11-dev python3-pip git curl screen

# ── 3. Clone or pull repo ─────────────────────────
echo "[3/7] Setting up bot directory..."
BOT_DIR="/opt/alex-encoder"

if [ -d "$BOT_DIR" ]; then
    echo "  → Directory exists, pulling latest..."
    cd "$BOT_DIR"
    git pull 2>/dev/null || true
else
    echo "  → Cloning repo..."
    read -rp "  Enter your Git repo URL (or press Enter to skip): " REPO_URL
    if [ -n "$REPO_URL" ]; then
        git clone "$REPO_URL" "$BOT_DIR"
    else
        mkdir -p "$BOT_DIR"
        echo "  → Skipped clone. Copy your files to $BOT_DIR manually."
    fi
fi

cd "$BOT_DIR"

# ── 4. Virtual environment & packages ─────────────
echo "[4/7] Setting up Python virtual environment..."
python3.11 -m venv venv
source venv/bin/activate

echo "  → Installing requirements..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

deactivate

# ── 5. Configure environment variables ───────────
echo "[5/7] Configuring environment..."

ENV_FILE="$BOT_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
    echo ""
    echo "══════════════════════════════"
    read -rp "  Enter your BOT_TOKEN: " BOT_TOKEN_VAL
    read -rp "  Enter ADMIN_IDS (comma-separated, e.g. 123456,789012): " ADMIN_IDS_VAL
    read -rp "  Enter FREE_DAILY_LIMIT (default 5): " FREE_LIMIT_VAL
    FREE_LIMIT_VAL="${FREE_LIMIT_VAL:-5}"
    read -rp "  Enter FORCE_JOIN_CHANNEL (e.g. @mychannel, or leave blank): " FORCE_JOIN_VAL
    echo "══════════════════════════════"

    cat > "$ENV_FILE" <<EOF
BOT_TOKEN=$BOT_TOKEN_VAL
ADMIN_IDS=$ADMIN_IDS_VAL
FREE_DAILY_LIMIT=$FREE_LIMIT_VAL
FORCE_JOIN_CHANNEL=$FORCE_JOIN_VAL
DB_PATH=$BOT_DIR/alex_encoder.db
BOT_USERNAME=AlexEncoderBot
EOF
    echo "  → .env saved to $ENV_FILE"
else
    echo "  → .env already exists, skipping."
fi

# ── 6. Create systemd service ─────────────────────
echo "[6/7] Creating systemd service for auto-restart..."

cat > /etc/systemd/system/alex-encoder.service <<EOF
[Unit]
Description=⚡ ALEX ENCODER ⚡ Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$BOT_DIR
EnvironmentFile=$BOT_DIR/.env
ExecStart=$BOT_DIR/venv/bin/python3 main.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 7. Enable & start service ─────────────────────
echo "[7/7] Enabling & starting bot service..."
systemctl daemon-reload
systemctl enable alex-encoder
systemctl restart alex-encoder

echo ""
echo "══════════════════════════════"
echo "✅ ALEX ENCODER is running 24/7!"
echo "══════════════════════════════"
echo ""
echo "Useful commands:"
echo "  View live logs  →  journalctl -u alex-encoder -f"
echo "  Stop bot        →  systemctl stop alex-encoder"
echo "  Start bot       →  systemctl start alex-encoder"
echo "  Restart bot     →  systemctl restart alex-encoder"
echo "  Bot status      →  systemctl status alex-encoder"
echo ""
