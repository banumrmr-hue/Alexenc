import asyncio
import logging
from telegram import Message

logger = logging.getLogger(__name__)

STEPS = {
    "obfuxtreme": [
        "⚡ Reading File...",
        "⚡ Collecting Variables...",
        "⚡ Applying AES String Encryption...",
        "⚡ Flattening Control Flow...",
        "⚡ Marshalling & Compressing...",
        "⚡ Generating Loader...",
        "✅ Obfuscation Complete!",
    ],
    "logic_changer": [
        "⚡ Reading File...",
        "⚡ Parsing AST...",
        "⚡ Generating State Machines...",
        "⚡ Flattening Control Flow...",
        "⚡ Restructuring Functions...",
        "✅ Logic Changed!",
    ],
    "expiry": [
        "⚡ Reading File...",
        "⚡ Validating Expiry Date...",
        "⚡ Injecting Expiry Protection...",
        "⚡ Adding Debugger Detection...",
        "⚡ Adding Time Tamper Guard...",
        "✅ Expiry Injected!",
    ],
    "shortpy": [
        "⚡ Reading File...",
        "⚡ Removing Comments...",
        "⚡ Renaming Variables...",
        "⚡ Combining Imports...",
        "⚡ Minifying Code...",
        "✅ Minification Complete!",
    ],
    "combo": [
        "⚡ Reading File...",
        "⚡ Stage 1: Short Py — Minifying...",
        "⚡ Stage 2: Logic Changer — Flattening...",
        "⚡ Stage 3: Expiry Inject — Protecting...",
        "⚡ Stage 4: ObfuXtreme — Encrypting...",
        "⚡ Finalizing Premium Protection...",
        "✅ Premium Combo Complete!",
    ],
}


async def animate_progress(msg: Message, module: str, delay: float = 0.6):
    steps = STEPS.get(module, ["⚡ Processing...", "✅ Done!"])
    for step in steps[:-1]:
        try:
            await msg.edit_text(
                f"<b>⚡ ALEX ENCODER ⚡</b>\n\n{step}",
                parse_mode="HTML",
            )
        except Exception:
            pass
        await asyncio.sleep(delay)
    return steps[-1]
